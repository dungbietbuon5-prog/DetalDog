// language: Swift, file: ContentView.swift
import SwiftUI
import UIKit

// --- KHAI BÁO CẤU TRÚC DỮ LIỆU ---
struct PatchFeature: Identifiable {
    let id = UUID()
    let name: String
    let desc: String
    let icon: String
    let color: Color
    let patchFileName: String
    var isOn: Bool = false
}

struct ContentView: View {
    @State private var selectedTab = 0
    @State private var showAlert = false
    @State private var alertMessage = ""
    
    // ĐƯỜNG DẪN GAME (Tự động tìm đường dẫn thư mục chứa file thật)
    // Mày cần đảm bảo app đã có quyền đọc/ghi thư mục này (TrollStore)
    
    // 1. TAB PROXY (Các loại Aim)
    @State private var proxyFeatures = [
        PatchFeature(name: "Proxy Body", desc: "Full Đồ Xóa Máu Vàng", icon: "figure.stand", color: .orange, patchFileName: "AimBody.3105"), // Mày có thể thay bằng file .3105 của mày
        PatchFeature(name: "Proxy Cổ V1", desc: "Aim Cổ Ít Lộ Hơn", icon: "scope", color: .yellow, patchFileName: "AimNeck-cache-.3105"),
        PatchFeature(name: "Proxy Cổ V2", desc: "Vùng Cổ Màu Đỏ To Hơn", icon: "target", color: .red, patchFileName: "AimNeck.3105"),
        PatchFeature(name: "Proxy Drag", desc: "Hỗ Trợ Kéo Nhẹ Tâm Lên Đầu", icon: "hand.draw.fill", color: .cyan, patchFileName: "AimDrag-Neck.3105"),
        PatchFeature(name: "Proxy Magic", desc: "Đạn Ma Thuật", icon: "wand.and.stars", color: .purple, patchFileName: "AimMagic.3105")
    ]
    
    // 2. TAB ĐỊNH VỊ (Dùng file Định Vị Súng)
    @State private var locationFeatures = [
        PatchFeature(name: "Định Vị Súng Xanh", desc: "Hiện Vị Trí Súng Trên Map", icon: "location.fill", color: .blue, patchFileName: "Định Vị Súng.3105"),
        PatchFeature(name: "Định Vị Súng Đỏ", desc: "Hiện Vị Trí Súng Trên Map", icon: "location.fill", color: .red, patchFileName: "Định Vị Súng.3105")
    ]
    
    // 3. TAB MOD NHÂN VẬT (Dùng file ModNVAlock)
    @State private var modNvFeatures = [
        PatchFeature(name: "Mod Skin Maro", desc: "Mod Skin Maro One Punch Man", icon: "person.fill", color: .orange, patchFileName: "ModNVAlock.3105")
    ]
    
    var body: some View {
        ZStack {
            // BACKGROUND TỐI MÀU NEON
            Color(red: 0.05, green: 0.02, blue: 0.1).edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 0) {
                // --- HEADER ---
                HStack {
                    Button(action: {}) {
                        Image(systemName: "chevron.left")
                            .font(.system(size: 20, weight: .bold))
                            .foregroundColor(.white)
                            .padding(10)
                            .background(Color.white.opacity(0.1))
                            .clipShape(Circle())
                    }
                    Spacer()
                    Text("Free Fire Thường")
                        .font(.system(size: 18, weight: .bold))
                        .foregroundColor(.white)
                    Spacer()
                    Color.clear.frame(width: 40, height: 40)
                }
                .padding(.horizontal, 20)
                .padding(.top, 10)
                
                // --- ICON GAME ---
                Image(systemName: "gamecontroller.fill")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 80, height: 80)
                    .foregroundColor(.orange)
                    .padding(10)
                    .background(Color.white.opacity(0.1))
                    .cornerRadius(20)
                    .padding(.top, 20)
                
                Text("Free Fire Thường")
                    .font(.system(size: 22, weight: .heavy))
                    .foregroundColor(.white)
                    .padding(.top, 10)
                
                Text("com.dts.freefireth")
                    .font(.system(size: 12, design: .monospaced))
                    .foregroundColor(.gray)
                    .padding(.bottom, 20)
                
                // --- TABS ---
                HStack(spacing: 0) {
                    TabButton(title: "Proxy", icon: "bolt.fill", isSelected: selectedTab == 0) { selectedTab = 0 }
                    TabButton(title: "Định Vị", icon: "location.fill", isSelected: selectedTab == 1) { selectedTab = 1 }
                    TabButton(title: "Mod NV", icon: "person.fill", isSelected: selectedTab == 2) { selectedTab = 2 }
                }
                .background(Color.white.opacity(0.05))
                .cornerRadius(15)
                .padding(.horizontal, 20)
                .padding(.bottom, 20)
                
                // --- DANH SÁCH CHỨC NĂNG ---
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 15) {
                        if selectedTab == 0 {
                            SectionHeader(title: "PROXY DELTA VIP", icon: "bolt.fill", badge: "AUTO")
                            ForEach($proxyFeatures) { $feature in
                                FeatureRow(feature: $feature, onToggle: { isOn in
                                    handlePatch(feature: feature, isTurningOn: isOn)
                                })
                            }
                        } else if selectedTab == 1 {
                            SectionHeader(title: "ĐỊNH VỊ SÚNG", icon: "location.fill", badge: "LIVE")
                            ForEach($locationFeatures) { $feature in
                                FeatureRow(feature: $feature, onToggle: { isOn in
                                    handlePatch(feature: feature, isTurningOn: isOn)
                                })
                            }
                        } else if selectedTab == 2 {
                            SectionHeader(title: "MOD NHÂN VẬT", icon: "person.fill", badge: "SOON")
                            ForEach($modNvFeatures) { $feature in
                                FeatureRow(feature: $feature, onToggle: { isOn in
                                    handlePatch(feature: feature, isTurningOn: isOn)
                                })
                            }
                        }
                    }
                    .padding(.horizontal, 20)
                }
                
                Spacer()
                
                // --- NÚT MỞ GAME ---
                Button(action: {
                    let url = URL(string: "freefireth://")!
                    if UIApplication.shared.canOpenURL(url) {
                        UIApplication.shared.open(url)
                    }
                }) {
                    HStack {
                        Image(systemName: "play.fill")
                        Text("MỞ GAME")
                            .font(.system(size: 18, weight: .bold))
                    }
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 16)
                    .background(
                        LinearGradient(gradient: Gradient(colors: [Color.purple, Color.cyan]), startPoint: .leading, endPoint: .trailing)
                    )
                    .cornerRadius(15)
                    .shadow(color: .purple.opacity(0.5), radius: 10, x: 0, y: 5)
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 30)
            }
        }
        .preferredColorScheme(.dark)
        .alert(isPresented: $showAlert) {
            Alert(title: Text("Thông báo"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
        }
    }
    
    // --- HÀM TỰ ĐỘNG TÌM ĐƯỜNG DẪN GAME ---
    func getGameTargetPath() -> String? {
        let fileManager = FileManager.default
        let appsPath = "/var/mobile/Containers/Data/Application/"
        
        if let apps = try? fileManager.contentsOfDirectory(atPath: appsPath) {
            for appUUID in apps {
                let appPath = appsPath + appUUID
                let metaPath = appPath + "/.com.apple.mobile_container_manager.metadata.plist"
                
                if let metaData = fileManager.contents(atPath: metaPath),
                   let plist = try? PropertyListSerialization.propertyList(from: metaData, options: [], format: nil) as? [String: Any],
                   let mcBundleID = plist["MCMMetadataIdentifier"] as? String,
                   mcBundleID == "com.dts.freefireth" {
                    return appPath + "/Documents/Assembly-CSharp-patch.bytes"
                }
            }
        }
        return nil
    }
    
    // --- HÀM TÌM FILE PATCH TRONG BUNDLE ---
    func findPatchFile(fileName: String) -> String? {
        guard let bundlePath = Bundle.main.resourcePath else { return nil }
        let fileManager = FileManager.default
        
        if let enumerator = fileManager.enumerator(atPath: bundlePath) {
            for case let path as String in enumerator {
                if path.hasSuffix(fileName) {
                    return "\(bundlePath)/\(path)"
                }
            }
        }
        return nil
    }

    // --- LOGIC GHI ĐÈ VÀ KHÔI PHỤC ---
    func handlePatch(feature: PatchFeature, isTurningOn: Bool) {
        let fileManager = FileManager.default
        
        guard let realGamePath = getGameTargetPath() else {
            alertMessage = "❌ Không tìm thấy game Free Fire trên máy! (Hãy chắc chắn app đã có quyền TrollStore/Root)"
            updateFeatureState(feature: feature, isOn: !isTurningOn)
            showAlert = true
            return
        }
        
        let gameBackupPath = realGamePath + ".orig"
        
        if isTurningOn {
            guard let sourcePath = findPatchFile(fileName: feature.patchFileName) else {
                alertMessage = "❌ LỖI: Không tìm thấy file \(feature.patchFileName) trong App!"
                updateFeatureState(feature: feature, isOn: false)
                showAlert = true
                return
            }
            
            do {
                if !fileManager.fileExists(atPath: gameBackupPath) && fileManager.fileExists(atPath: realGamePath) {
                    try fileManager.copyItem(atPath: realGamePath, toPath: gameBackupPath)
                }
                
                if fileManager.fileExists(atPath: realGamePath) {
                    try fileManager.removeItem(atPath: realGamePath)
                }
                try fileManager.copyItem(atPath: sourcePath, toPath: realGamePath)
                
                alertMessage = "✅ Đã bật \(feature.name)!"
            } catch {
                alertMessage = "❌ Lỗi ghi đè (Cần quyền TrollStore/Root): \(error.localizedDescription)"
                updateFeatureState(feature: feature, isOn: false)
            }
        } else {
            do {
                if fileManager.fileExists(atPath: gameBackupPath) {
                    if fileManager.fileExists(atPath: realGamePath) {
                        try fileManager.removeItem(atPath: realGamePath)
                    }
                    try fileManager.copyItem(atPath: gameBackupPath, toPath: realGamePath)
                    alertMessage = "♻️ Đã tắt \(feature.name) và khôi phục file gốc!"
                } else {
                    alertMessage = "⚠️ Không tìm thấy file Backup gốc!"
                }
            } catch {
                alertMessage = "❌ Lỗi khôi phục: \(error.localizedDescription)"
            }
        }
        showAlert = true
    }
    
    func updateFeatureState(feature: PatchFeature, isOn: Bool) {
        if let index = proxyFeatures.firstIndex(where: { $0.id == feature.id }) {
            proxyFeatures[index].isOn = isOn
        } else if let index = locationFeatures.firstIndex(where: { $0.id == feature.id }) {
            locationFeatures[index].isOn = isOn
        } else if let index = modNvFeatures.firstIndex(where: { $0.id == feature.id }) {
            modNvFeatures[index].isOn = isOn
        }
    }
}

// --- COMPONENT NÚT TAB ---
struct TabButton: View {
    let title: String
    let icon: String
    let isSelected: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            HStack {
                Image(systemName: icon)
                Text(title)
            }
            .font(.system(size: 13, weight: .bold))
            .foregroundColor(isSelected ? .white : .gray)
            .padding(.vertical, 12)
            .frame(maxWidth: .infinity)
            .background(isSelected ? Color.white.opacity(0.1) : Color.clear)
            .cornerRadius(12)
        }
    }
}

// --- COMPONENT TIÊU ĐỀ MỤC ---
struct SectionHeader: View {
    let title: String
    let icon: String
    let badge: String
    
    var body: some View {
        HStack {
            Label(title, systemImage: icon)
                .font(.system(size: 12, weight: .bold))
                .foregroundColor(.cyan)
            Spacer()
            Text(badge)
                .font(.system(size: 10, weight: .bold))
                .padding(.horizontal, 8)
                .padding(.vertical, 4)
                .background(Color.white.opacity(0.1))
                .cornerRadius(8)
                .foregroundColor(.gray)
        }
        .padding(.horizontal, 5)
        .padding(.top, 10)
    }
}

// --- COMPONENT DÒNG CHỨC NĂNG ---
struct FeatureRow: View {
    @Binding var feature: PatchFeature
    var onToggle: (Bool) -> Void
    
    var body: some View {
        HStack(spacing: 15) {
            Image(systemName: feature.icon)
                .font(.system(size: 20, weight: .bold))
                .foregroundColor(.white)
                .frame(width: 45, height: 45)
                .background(feature.color)
                .cornerRadius(12)
            
            VStack(alignment: .leading, spacing: 4) {
                Text(feature.name)
                    .font(.system(size: 15, weight: .bold))
                    .foregroundColor(.white)
                Text(feature.desc)
                    .font(.system(size: 11))
                    .foregroundColor(.gray)
            }
            
            Spacer()
            
            Toggle("", isOn: $feature.isOn)
                .labelsHidden()
                .onChange(of: feature.isOn) { newValue in
                    onToggle(newValue)
                }
                .tint(.green) // Màu xanh lá khi bật
        }
        .padding()
        .background(Color.white.opacity(0.05))
        .cornerRadius(15)
        .overlay(
            RoundedRectangle(cornerRadius: 15)
                .stroke(feature.isOn ? Color.green.opacity(0.5) : Color.white.opacity(0.1), lineWidth: 1)
        )
    }
}