// language: Swift, file: ContentView.swift
import SwiftUI
import UIKit

struct PatchFeature: Identifiable {
    let id = UUID()
    let name: String
    let desc: String
    let icon: String
    let color: Color
    let patchFolderName: String
    let gameTargetPath: String
    var isOn: Bool = false
}

struct ContentView: View {
    @State private var selectedTab = 0
    @State private var showAlert = false
    @State private var alertMessage = ""
    
    // 1. TAB PROXY
    @State private var proxyFeatures = [
        PatchFeature(name: "Aim Body", desc: "Full Đồ Xóa Máu Vàng", icon: "figure.stand", color: .orange, patchFolderName: "AimBody", gameTargetPath: "/Documents/contencache/Compulsory/ios/gameassetbundles"),
        PatchFeature(name: "Aim Drag", desc: "Hỗ Trợ Kéo Nhẹ Tâm Lên Đầu", icon: "hand.draw.fill", color: .cyan, patchFolderName: "AimDrag", gameTargetPath: "/Documents/contencache/Compulsory/ios/gameassetbundles"),
        PatchFeature(name: "Aim Magic", desc: "Đạn Ma Thuật", icon: "wand.and.stars", color: .purple, patchFolderName: "AimMagic", gameTargetPath: "/Documents/contencache/Compulsory/ios/gameassetbundles"),
        PatchFeature(name: "Aim Neck", desc: "Aim Cổ Ít Lộ", icon: "scope", color: .yellow, patchFolderName: "AimNeck", gameTargetPath: "/Documents/contencache/Compulsory/ios/gameassetbundles")
    ]
    
    // 2. TAB ĐỊNH VỊ
    @State private var locationFeatures = [
        PatchFeature(name: "Định Vị Súng", desc: "Hiện Vị Trí Súng Trên Map", icon: "location.fill", color: .blue, patchFolderName: "Định Vị Súng", gameTargetPath: "/Documents/contencache/optional/ios/gameassetbundles")
    ]
    
    // 3. TAB MOD NHÂN VẬT
    @State private var modNvFeatures = [
        PatchFeature(name: "Mod Alock", desc: "Khóa Mục Tiêu Nhân Vật", icon: "person.fill", color: .pink, patchFolderName: "ModAlock", gameTargetPath: "/Documents/optional/ios/optionalavatarres/gameassetbundles")
    ]
    
    var body: some View {
        ZStack {
            Color(red: 0.05, green: 0.02, blue: 0.1).edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 0) {
                // HEADER
                HStack {
                    Button(action: {}) {
                        Image(systemName: "chevron.left")
                            .font(.system(size: 20, weight: .bold))
                            .foregroundColor(.white)
                            .padding(10)
                            .background(Color.white.opacity(0.1))
                            .clipShape(Circle())
                    }
                    Spacer()
                    Text("Free Fire Thường")
                        .font(.system(size: 18, weight: .bold))
                        .foregroundColor(.white)
                    Spacer()
                    Color.clear.frame(width: 40, height: 40)
                }
                .padding(.horizontal, 20)
                .padding(.top, 10)
                
                // ICON
                Image(systemName: "gamecontroller.fill")
                    .resizable().scaledToFit().frame(width: 80, height: 80)
                    .foregroundColor(.orange).padding(10)
                    .background(Color.white.opacity(0.1)).cornerRadius(20)
                    .padding(.top, 20)
                
                Text("Free Fire Thường").font(.system(size: 22, weight: .heavy)).foregroundColor(.white).padding(.top, 10)
                Text("com.dts.freefireth").font(.system(size: 12, design: .monospaced)).foregroundColor(.gray).padding(.bottom, 20)
                
                // TABS
                HStack(spacing: 0) {
                    TabButton(title: "Proxy", icon: "bolt.fill", isSelected: selectedTab == 0) { selectedTab = 0 }
                    TabButton(title: "Định Vị", icon: "location.fill", isSelected: selectedTab == 1) { selectedTab = 1 }
                    TabButton(title: "Mod NV", icon: "person.fill", isSelected: selectedTab == 2) { selectedTab = 2 }
                }
                .background(Color.white.opacity(0.05))
                .cornerRadius(15)
                .padding(.horizontal, 20)
                .padding(.bottom, 20)
                
                // DANH SÁCH
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 15) {
                        if selectedTab == 0 {
                            ForEach($proxyFeatures) { $feature in
                                FeatureRow(feature: $feature, onToggle: { isOn in handlePatch(feature: feature, isOn: isOn) })
                            }
                        } else if selectedTab == 1 {
                            ForEach($locationFeatures) { $feature in
                                FeatureRow(feature: $feature, onToggle: { isOn in handlePatch(feature: feature, isOn: isOn) })
                            }
                        } else if selectedTab == 2 {
                            ForEach($modNvFeatures) { $feature in
                                FeatureRow(feature: $feature, onToggle: { isOn in handlePatch(feature: feature, isOn: isOn) })
                            }
                        }
                    }
                    .padding(.horizontal, 20)
                }
                
                Spacer()
                
                // NÚT MỞ GAME
                Button(action: {
                    let url = URL(string: "freefireth://")!
                    if UIApplication.shared.canOpenURL(url) { UIApplication.shared.open(url) }
                }) {
                    HStack {
                        Image(systemName: "play.fill")
                        Text("MỞ GAME").font(.system(size: 18, weight: .bold))
                    }
                    .foregroundColor(.white).frame(maxWidth: .infinity).padding(.vertical, 16)
                    .background(LinearGradient(gradient: Gradient(colors: [Color.purple, Color.cyan]), startPoint: .leading, endPoint: .trailing))
                    .cornerRadius(15).shadow(color: .purple.opacity(0.5), radius: 10, x: 0, y: 5)
                }
                .padding(.horizontal, 20).padding(.bottom, 30)
            }
        }
        .preferredColorScheme(.dark)
        .alert(isPresented: $showAlert) {
            Alert(title: Text("Thông báo"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
        }
    }
    
    // TÌM ĐƯỜNG DẪN GAME
    func getGameBasePath() -> String? {
        let fileManager = FileManager.default
        let appsPath = "/var/mobile/Containers/Data/Application/"
        
        if let apps = try? fileManager.contentsOfDirectory(atPath: appsPath) {
            for appUUID in apps {
                let appPath = appsPath + appUUID
                let metaPath = appPath + "/.com.apple.mobile_container_manager.metadata.plist"
                
                if let metaData = fileManager.contents(atPath: metaPath),
                   let plist = try? PropertyListSerialization.propertyList(from: metaData, options: [], format: nil) as? [String: Any],
                   let mcBundleID = plist["MCMMetadataIdentifier"] as? String,
                   mcBundleID == "com.dts.freefireth" {
                    return appPath
                }
            }
        }
        return nil
    }
    
    // TÌM THƯ MỤC PATCH (ĐÃ FIX ĐƯỜNG DẪN CÓ CHỮ PATCHES)
    func findBundleFolder(folderName: String) -> String? {
        guard let bundlePath = Bundle.main.resourcePath else { return nil }
        let fullPath = bundlePath + "/Patches/" + folderName
        if FileManager.default.fileExists(atPath: fullPath) { return fullPath }
        return nil
    }

    // LOGIC BẬT / TẮT
    func handlePatch(feature: PatchFeature, isOn: Bool) {
        DispatchQueue.global(qos: .userInitiated).async {
            let fileManager = FileManager.default
            
            guard let gameBase = getGameBasePath() else {
                self.showMsg("❌ Không tìm thấy game! Hãy chắc chắn mày cài bằng TrollStore/Esign có Entitlements.")
                self.resetSwitch(feature: feature)
                return
            }
            
            let targetDir = gameBase + feature.gameTargetPath
            let backupDir = targetDir + ".orig_backup"
            
            if isOn {
                guard let sourceFolder = self.findBundleFolder(folderName: feature.patchFolderName) else {
                    self.showMsg("❌ Không tìm thấy thư mục \(feature.patchFolderName) trong Patches!")
                    self.resetSwitch(feature: feature)
                    return
                }
                
                do {
                    // 1. Backup file gốc
                    if !fileManager.fileExists(atPath: backupDir) && fileManager.fileExists(atPath: targetDir) {
                        try fileManager.copyItem(atPath: targetDir, toPath: backupDir)
                    }
                    
                    // 2. Ghi đè patch
                    if fileManager.fileExists(atPath: targetDir) {
                        try fileManager.removeItem(atPath: targetDir)
                    }
                    try fileManager.copyItem(atPath: sourceFolder, toPath: targetDir)
                    
                    self.showMsg("✅ Đã bật \(feature.name) thành công!")
                    
                } catch {
                    self.showMsg("❌ Lỗi ghi đè: \(error.localizedDescription)")
                    self.resetSwitch(feature: feature)
                }
            } else {
                // KHÔI PHỤC
                do {
                    if fileManager.fileExists(atPath: backupDir) {
                        if fileManager.fileExists(atPath: targetDir) {
                            try fileManager.removeItem(atPath: targetDir)
                        }
                        try fileManager.copyItem(atPath: backupDir, toPath: targetDir)
                        self.showMsg("♻️ Đã tắt \(feature.name) và khôi phục file gốc!")
                    }
                } catch {
                    self.showMsg("❌ Lỗi khôi phục: \(error.localizedDescription)")
                }
            }
        }
    }
    
    func showMsg(_ msg: String) {
        DispatchQueue.main.async { self.alertMessage = msg; self.showAlert = true }
    }
    
    func resetSwitch(feature: PatchFeature) {
        DispatchQueue.main.async {
            if let i = proxyFeatures.firstIndex(where: {$0.id == feature.id}) { proxyFeatures[i].isOn = false }
            if let i = locationFeatures.firstIndex(where: {$0.id == feature.id}) { locationFeatures[i].isOn = false }
            if let i = modNvFeatures.firstIndex(where: {$0.id == feature.id}) { modNvFeatures[i].isOn = false }
        }
    }
}

// COMPONENTS
struct TabButton: View {
    let title: String; let icon: String; let isSelected: Bool; let action: () -> Void
    var body: some View {
        Button(action: action) {
            HStack { Image(systemName: icon); Text(title) }
            .font(.system(size: 13, weight: .bold)).foregroundColor(isSelected ? .white : .gray)
            .padding(.vertical, 12).frame(maxWidth: .infinity)
            .background(isSelected ? Color.white.opacity(0.1) : Color.clear).cornerRadius(12)
        }
    }
}

struct FeatureRow: View {
    @Binding var feature: PatchFeature
    var onToggle: (Bool) -> Void
    var body: some View {
        HStack(spacing: 15) {
            Image(systemName: feature.icon).font(.system(size: 20, weight: .bold)).foregroundColor(.white)
                .frame(width: 45, height: 45).background(feature.color).cornerRadius(12)
            
            VStack(alignment: .leading, spacing: 4) {
                Text(feature.name).font(.system(size: 15, weight: .bold)).foregroundColor(.white)
                Text(feature.desc).font(.system(size: 11)).foregroundColor(.gray)
            }
            Spacer()
            Toggle("", isOn: $feature.isOn).labelsHidden().onChange(of: feature.isOn) { newValue in onToggle(newValue) }.tint(.green)
        }
        .padding().background(Color.white.opacity(0.05)).cornerRadius(15)
        .overlay(RoundedRectangle(cornerRadius: 15).stroke(feature.isOn ? Color.green.opacity(0.5) : Color.white.opacity(0.1), lineWidth: 1))
    }
}